// services/api.js
import {
  systemData as mockSystemData,
  machineData as mockMachineData,
  vibrationData as mockVibrationData,
  temperatureData as mockTemperatureData,
  currentData as mockCurrentData,
  prediction as mockPrediction,
  faultHistory as mockFaultHistory,
  faultStats as mockFaultStats,
} from "../data/mockData";

// Real Azure Function URLs
const TELEMETRY_URL = "https://pm-api-demo-d8gmgvfvanc2e5ft.southeastasia-01.azurewebsites.net/api/getTelemetry";
const TELEMETRY_HISTORY_URL = "https://pm-api-demo-d8gmgvfvanc2e5ft.southeastasia-01.azurewebsites.net/api/getTelemetryHistory";

// Helper function to simulate API delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ============================================
// SYSTEM STATUS (Mock)
// ============================================
export const getSystemStatus = async () => {
  await delay(300);
  return mockSystemData;
};

// ============================================
// MACHINE DATA (Mock)
// ============================================
export const getMachineData = async () => {
  await delay(300);
  return mockMachineData;
};

// ============================================
// TELEMETRY DATA (Real from Azure Function)
// ============================================
export const getMachineTelemetry = async () => {
  try {
    const response = await fetch(TELEMETRY_URL);
    if (!response.ok) throw new Error("Failed to fetch telemetry");
    const data = await response.json();

    // Compute vibration RMS
    const vibration = Math.sqrt(
      (+data.ax) ** 2 + (+data.ay) ** 2 + (+data.az) ** 2
    );

    return {
      timestamp: new Date().toLocaleTimeString(),
      current: +data.current,
      temperature: +data.temp,
      vibration: +vibration.toFixed(3),
      raw: data, // Keep original values if needed
    };
  } catch (error) {
    console.error("Telemetry API Error:", error);
    return {
      timestamp: new Date().toLocaleTimeString(),
      current: 0,
      temperature: 0,
      vibration: 0,
      raw: {},
    };
  }
};

// ============================================
// TELEMETRY HISTORY (Real from Azure Function)
// ============================================
export const getTelemetryHistory = async () => {
  try {
    const response = await fetch(TELEMETRY_HISTORY_URL);
    if (!response.ok) throw new Error("Failed to fetch telemetry history");
    const data = await response.json();

    // Transform the data into chart-friendly format
    return data.map((row, index) => {
      const vibration = Math.sqrt(
        (+row.ax || 0) ** 2 + (+row.ay || 0) ** 2 + (+row.az || 0) ** 2
      );

      return {
        timestamp: row.timestamp || new Date(Date.now() - (data.length - index) * 1000).toLocaleTimeString(),
        time: row.timestamp || new Date(Date.now() - (data.length - index) * 1000).toLocaleTimeString(),
        current: +row.current || 0,
        temp: +row.temp || 0,
        temperature: +row.temp || 0,
        vibration: +vibration.toFixed(3),
        ax: +row.ax || 0,
        ay: +row.ay || 0,
        az: +row.az || 0,
      };
    });
  } catch (error) {
    console.error("Telemetry History API Error:", error);
    return [];
  }
};

// ============================================
// LIVE STREAM (Polling Azure Function)
// ============================================
export const connectToLiveStream = (onData, onError, intervalMs = 2000) => {
  const interval = setInterval(async () => {
    try {
      const telemetry = await getMachineTelemetry();
      onData(telemetry);
    } catch (err) {
      onError(err);
    }
  }, intervalMs);

  return () => clearInterval(interval);
};

// ============================================
// VIBRATION / TEMP / CURRENT DATA (Mock)
// ============================================
export const getVibrationData = async (limit = 50) => mockVibrationData.slice(-limit);
export const getTemperatureData = async (limit = 50) => mockTemperatureData.slice(-limit);
export const getCurrentData = async (limit = 50) => mockCurrentData.slice(-limit);

// ============================================
// PREDICTIONS (Mock)
// ============================================
export const getPredictions = async () => {
  await delay(200);
  return mockPrediction;
};

// ============================================
// FAULT HISTORY / STATS (Mock)
// ============================================
export const getFaultHistory = async (startDate = null, endDate = null) => mockFaultHistory;
export const getFaultStats = async () => mockFaultStats;

// ============================================
// SETTINGS (Mock / Placeholder)
// ============================================
export const testConnection = async () => Math.random() > 0.2;
export const updateThresholds = async (thresholds) => {
  await delay(500);
  console.log("Mock: Thresholds updated", thresholds);
  return { success: true };
};

// ============================================
// EXPORT CONFIGURATION
// ============================================
export const API_CONFIG = {
  TELEMETRY_URL,
  TELEMETRY_HISTORY_URL,
};